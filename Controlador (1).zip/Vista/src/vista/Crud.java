/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package vista;

import java.util.List;

public interface Crud<P> {
    public List<P> mostrar();
    public int setAgregar(P producto);//tr nombre aleatorio
    public int setActualizar(P producto);
    public int setEliminar(int idProducto);
}


